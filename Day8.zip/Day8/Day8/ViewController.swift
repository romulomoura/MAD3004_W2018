//
//  ViewController.swift
//  Day8
//
//  Created by MacStudent on 2018-03-01.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MapKit


class ViewController: UIViewController {

    @IBOutlet weak var myMap: MKMapView!
    let lambtonCollegeLocation = CLLocation(latitude: 43.773257, longitude: -79.335899)
    
    let cnTowerLocation = CLLocation(latitude: 43.642566, longitude: -79.387057)
    
    
    let regionRadius: CLLocationDistance = 10000
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.myMap.mapType = MKMapType.standard
        //centerMapOnLocation(location: lambtonCollegeLocation)
        centerMapOnLocation(location:cnTowerLocation)
        
        setMarkerOnMap(location: cnTowerLocation, title: "CN Tower", subTitle: "Toronto, ON, CA")
    
    }

    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate,
                                                                  regionRadius,    regionRadius)
        myMap.setRegion(coordinateRegion, animated: true)
    }
    
    func setMarkerOnMap(location: CLLocation, title: String, subTitle: String)
    {
        // Drop a pin at user's Current Location
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(location.coordinate.latitude, location.coordinate.longitude);
        //myAnnotation.title = "C N Tower"
        //myAnnotation.subtitle = "100 Lake Road, Toronto"
        myMap.addAnnotation(myAnnotation)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

